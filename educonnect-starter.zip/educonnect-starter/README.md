
# Educonnect — Starter Repo (Simplified)

This starter includes:
- frontend/ : A Next.js app (very small) with a VideoCall component and a quiz API route.
- signaling/ : A minimal Node.js Socket.IO signaling server for WebRTC.
This is a **starter** to help you build Educonnect. It does NOT include full features (authentication, translations, admin dashboard). Follow the deploy steps below.

## What I can NOT do
I cannot host the app for you. But you can deploy for free using services below. Because you're under 18, ask a parent/guardian to help create accounts (hosting providers require email and may require payment methods). Parental consent is important.

## Recommended free hosting (examples)
- Frontend (Next.js): Vercel (Hobby - free) or Netlify / Cloudflare Pages.
- Signaling server: Render free web service, Railway free, or a small VPS. (Some providers change policies; check their websites.)
- Database & storage: Supabase free tier (for Postgres + Storage).

## Quick deploy guide (fast path)
1. Create a GitHub account (ask parent to help).
2. Push this repo to GitHub.
3. Deploy frontend:
   - Go to https://vercel.com, sign up, import the `frontend` directory as a Next.js project.
   - Set `NEXT_PUBLIC_SIGNALING_SERVER` environment variable to your signaling server URL.
4. Deploy signaling server:
   - Use https://render.com or https://railway.app, create a new Web Service, connect to the `signaling` folder.
   - Start service; copy the public URL and paste into Vercel env var above.
5. Test: open the Vercel site on two devices/tabs and try the VideoCall demo.

## Files included
- frontend/pages/index.js
- frontend/components/VideoCall.jsx
- frontend/pages/api/quiz.js
- signaling/server.js

## Next steps (recommended)
- Add authentication (phone OTP or email).
- Integrate translation APIs (Google Cloud Translate) and speech-to-text.
- Add parental consent flow and moderation.
- Replace simple signaling with TURN server (coturn) or use a hosted RTC provider (Daily.co) for reliability.

## Parental safety note
Because learners may be children, get a parent or teacher involved when deploying, adding volunteers, and using the app. Don't share personal contact details publicly.

