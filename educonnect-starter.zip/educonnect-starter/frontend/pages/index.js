
import Head from 'next/head'
import dynamic from 'next/dynamic'
const VideoCall = dynamic(()=>import('../components/VideoCall'), {ssr:false})
export default function Home(){
  return (
    <div style={{padding:20, fontFamily:'Arial'}}>
      <Head><title>Educonnect — Starter</title></Head>
      <h1>Educonnect — Starter App</h1>
      <p>This is a simplified starter demo: video call, chat, simple quiz API, and deploy steps in README.</p>
      <VideoCall />
    </div>
  )
}
