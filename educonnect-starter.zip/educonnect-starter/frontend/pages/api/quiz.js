
// Simple quiz API (Next.js API route) - returns a sample quiz and grades answers
export default function handler(req, res){
  if(req.method === 'GET'){
    const quiz = {
      id: 'sample-1',
      title: 'Basic Math',
      questions: [
        {id:'q1', text:'2 + 3 = ?', type:'mcq', options:['4','5','6'], answer:'5'},
        {id:'q2', text:'5 - 2 = ?', type:'mcq', options:['2','3','4'], answer:'3'}
      ]
    };
    return res.json(quiz);
  } else if(req.method === 'POST'){
    const {answers} = req.body;
    // naive grading
    const correct = {'q1':'5','q2':'3'};
    let score = 0;
    for(const a of answers) if(correct[a.questionId] === a.answer) score++;
    return res.json({score, total: Object.keys(correct).length});
  } else {
    res.status(405).end();
  }
}
