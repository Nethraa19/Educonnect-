
import React, {useRef, useEffect, useState} from 'react';
import io from 'socket.io-client';
import SimplePeer from 'simple-peer';

const SIGNALING_SERVER = process.env.NEXT_PUBLIC_SIGNALING_SERVER || 'https://YOUR-SIGNALING-SERVER';
let socket;

export default function VideoCall(){
  const localRef = useRef();
  const remoteRef = useRef();
  const peerRef = useRef();
  const [joined, setJoined] = useState(false);

  useEffect(()=>{
    async function init(){
      socket = io(process.env.NEXT_PUBLIC_SIGNALING_SERVER || 'https://YOUR-SIGNALING-SERVER');
      const stream = await navigator.mediaDevices.getUserMedia({video:true, audio:true}).catch(()=>null);
      if(stream && localRef.current) localRef.current.srcObject = stream;
      socket.on('connect', ()=>console.log('connected to signaling', socket.id));
      socket.on('user-joined', ({socketId})=>{
        if(stream){
          const p = new SimplePeer({initiator:true, trickle:false, stream});
          peerRef.current = p;
          p.on('signal', sig => socket.emit('signal', {to: socketId, from: socket.id, signal: sig}));
          p.on('stream', s => remoteRef.current.srcObject = s);
        }
      });
      socket.on('signal', ({from, signal})=>{
        if(!peerRef.current && stream){
          const p = new SimplePeer({initiator:false, trickle:false, stream});
          peerRef.current = p;
          p.on('signal', sig => socket.emit('signal', {to: from, from: socket.id, signal: sig}));
          p.on('stream', s => remoteRef.current.srcObject = s);
        }
        if(peerRef.current) peerRef.current.signal(signal);
      });
    }
    init();
    return ()=>{ if(socket) socket.disconnect(); if(peerRef.current) peerRef.current.destroy(); }
  },[]);

  return (
    <div>
      <div>
        <video ref={localRef} autoPlay playsInline muted style={{width:240,height:180,background:'#000'}}/>
        <video ref={remoteRef} autoPlay playsInline style={{width:240,height:180,background:'#000'}}/>
      </div>
      <p>Note: replace NEXT_PUBLIC_SIGNALING_SERVER with your signaling server URL (see README).</p>
    </div>
  )
}
